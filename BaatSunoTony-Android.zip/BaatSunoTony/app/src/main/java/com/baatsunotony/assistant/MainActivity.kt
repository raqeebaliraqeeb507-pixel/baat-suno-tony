package com.baatsunotony.assistant

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.baatsunotony.assistant.accessibility.TonyAccessibilityService
import com.baatsunotony.assistant.notification.TonyNotificationListenerService
import com.baatsunotony.assistant.service.TonyVoiceService
import com.baatsunotony.assistant.state.AssistantStateBus
import com.baatsunotony.assistant.state.ListeningPhase
import com.baatsunotony.assistant.state.RecognitionLanguage

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        refreshSystemServiceStates()

        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Color(0xFF0D9488),
                    background = Color(0xFFF8FAFC),
                    surface = Color.White,
                    onBackground = Color(0xFF0F172A),
                    onSurface = Color(0xFF0F172A)
                )
            ) {
                TonyAssistantScreen(
                    onRefreshStatuses = { refreshSystemServiceStates() },
                    onStartService = { startTonyService() },
                    onStopService = { stopTonyService() }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshSystemServiceStates()
    }

    private fun refreshSystemServiceStates() {
        AssistantStateBus.setAccessibilityConnected(isAccessibilityEnabled(this))
        AssistantStateBus.setNotificationListenerConnected(isNotificationListenerEnabled(this))
    }

    private fun startTonyService() {
        val intent = Intent(this, TonyVoiceService::class.java).apply {
            action = TonyVoiceService.ACTION_START
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopTonyService() {
        val intent = Intent(this, TonyVoiceService::class.java).apply {
            action = TonyVoiceService.ACTION_STOP
        }
        startService(intent)
    }

    private fun isAccessibilityEnabled(context: Context): Boolean {
        val expectedComponent = ComponentName(context, TonyAccessibilityService::class.java)
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabledServices)
        while (splitter.hasNext()) {
            val componentName = ComponentName.unflattenFromString(splitter.next())
            if (componentName == expectedComponent) return true
        }
        return false
    }

    private fun isNotificationListenerEnabled(context: Context): Boolean {
        val flat = Settings.Secure.getString(
            context.contentResolver,
            "enabled_notification_listeners"
        ) ?: return false
        val expected = ComponentName(context, TonyNotificationListenerService::class.java).flattenToString()
        return flat.split(":").any { it.equals(expected, ignoreCase = true) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TonyAssistantScreen(
    onRefreshStatuses: () -> Unit,
    onStartService: () -> Unit,
    onStopService: () -> Unit
) {
    val context = LocalContext.current
    val state by AssistantStateBus.uiState.collectAsState()
    var manualInput by remember { mutableStateOf("") }

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        hasMicPermission = results[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (hasMicPermission) {
            onStartService()
        }
    }

    LaunchedEffect(Unit) {
        onRefreshStatuses()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Baat Suno Tony",
                        fontWeight = FontWeight.Bold
                    )
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Voice Service Control Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White, RoundedCornerShape(16.dp))
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val statusLabel = when (state.phase) {
                    ListeningPhase.STOPPED -> "Standby — Service Stopped"
                    ListeningPhase.WAKE_WORD_STANDBY -> "Listening for \"Baat Suno Tony\""
                    ListeningPhase.ACTIVE_COMMAND -> "Listening for your command..."
                    ListeningPhase.THINKING -> "Tony is thinking..."
                    ListeningPhase.SPEAKING -> "Tony is speaking..."
                }

                Text(
                    text = statusLabel,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )

                if (state.liveTranscript.isNotBlank()) {
                    Text(
                        text = "Heard: \"${state.liveTranscript}\"",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF0D9488)
                    )
                }

                if (!state.lastError.isNullOrBlank()) {
                    Text(
                        text = state.lastError.orEmpty(),
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFDC2626)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!state.isServiceRunning) {
                        Button(
                            onClick = {
                                val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    perms.add(Manifest.permission.POST_NOTIFICATIONS)
                                }
                                if (hasMicPermission) {
                                    onStartService()
                                } else {
                                    permissionLauncher.launch(perms.toTypedArray())
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488))
                        ) {
                            Icon(Icons.Default.Mic, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Start Wake-Word Service")
                        }
                    } else {
                        OutlinedButton(onClick = onStopService) {
                            Icon(Icons.Default.Stop, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Stop Listening")
                        }
                    }
                }

                // Language Selection
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    RecognitionLanguage.entries.forEach { lang ->
                        FilterChip(
                            selected = state.preferredLanguage == lang,
                            onClick = { AssistantStateBus.setPreferredLanguage(lang) },
                            label = { Text(lang.label) }
                        )
                    }
                }
            }

            // System Permissions & Handlers Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White, RoundedCornerShape(16.dp))
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "System Services",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Accessibility Controls", fontWeight = FontWeight.Medium)
                        Text(
                            text = if (state.accessibilityConnected) "Connected — Open apps, scroll & click" else "Enable in Settings for screen actions",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF64748B)
                        )
                    }
                    OutlinedButton(
                        onClick = {
                            context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }
                    ) {
                        Text(if (state.accessibilityConnected) "Enabled" else "Enable")
                    }
                }

                HorizontalDivider(color = Color(0xFFF1F5F9))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Notification Reader", fontWeight = FontWeight.Medium)
                        Text(
                            text = if (state.notificationListenerConnected) "Connected — Reads incoming messages" else "Enable Notification Access",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF64748B)
                        )
                    }
                    OutlinedButton(
                        onClick = {
                            context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                        }
                    ) {
                        Text(if (state.notificationListenerConnected) "Enabled" else "Enable")
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Auto-read incoming messages aloud")
                    Switch(
                        checked = state.autoReadNotifications,
                        onCheckedChange = { AssistantStateBus.setAutoReadNotifications(it) }
                    )
                }
            }

            // Conversation Log
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(Color.White, RoundedCornerShape(16.dp))
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (state.chatHistory.isEmpty()) {
                    item {
                        Text(
                            text = "Say \"Baat Suno Tony\" or type a command below like \"YouTube kholo\" or \"Mere messages parho\".",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFF64748B)
                        )
                    }
                }
                items(state.chatHistory, key = { it.id }) { entry ->
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = entry.sender,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (entry.sender == "Tony") Color(0xFF0D9488) else Color(0xFF475569),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = entry.text,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        if (!entry.actionLabel.isNullOrBlank()) {
                            Text(
                                text = "Action: ${entry.actionLabel}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                }
            }

            // Manual Command Input Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = manualInput,
                    onValueChange = { manualInput = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Ask Tony in Urdu or English...") },
                    singleLine = true
                )
                Spacer(Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        val trimmed = manualInput.trim()
                        if (trimmed.isNotEmpty()) {
                            if (!state.isServiceRunning) {
                                onStartService()
                            }
                            AssistantStateBus.submitManualCommand(trimmed)
                            manualInput = ""
                        }
                    }
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
                }
            }
        }
    }
}
