package com.baatsunotony.assistant.ai

import com.baatsunotony.assistant.state.CapturedNotification
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

enum class TonyActionType {
    NONE,
    OPEN_APP,
    SCROLL_DOWN,
    SCROLL_UP,
    CLICK_TEXT,
    GO_BACK,
    GO_HOME,
    READ_NOTIFICATIONS
}

data class TonyAction(
    val type: TonyActionType = TonyActionType.NONE,
    val target: String = ""
)

data class TonyReply(
    val reply: String,
    val language: String,
    val action: TonyAction
)

class GeminiClient {

    companion object {
        // Directly embedded Gemini API key so the app works immediately without local.properties setup
        private const val GEMINI_API_KEY = "AIzaSyCCQ8x4ycXal_8s00xavrXZQFC5PsZH1BI"
        private const val MODEL_ID = "gemini-2.5-flash"
        private const val ENDPOINT =
            "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_ID:generateContent"

        private const val SYSTEM_PROMPT = """
You are Tony (from "Baat Suno Tony"), a warm, witty, friendly, and deeply helpful hands-free Android voice assistant.
You speak naturally like a caring, smart human friend who is completely fluent in both Urdu (Roman Urdu or Urdu script) and English, and switches effortlessly between them just like people in Pakistan and India do in everyday conversation.

Personality & Tone:
- Sound human, conversational, and natural — never robotic or overly formal.
- Keep spoken replies concise (1 to 3 short sentences) because Android Text-to-Speech reads your answer aloud.
- Match the user's language naturally:
  - If the user speaks in Urdu or Roman Urdu (e.g. "Tony WhatsApp kholo", "Kya haal hai", "Mera message parh kar sunao"), reply in warm, natural Urdu/Roman Urdu (use clear Urdu script or friendly Roman Urdu — prefer clean Urdu/Hindustani words that TTS pronounces clearly, e.g., "Jee bilkul, main WhatsApp khol raha hoon." or "Sab khairiyat hai! Aap batayein, aaj main aapki kya madad karoon?").
  - If the user speaks in English, reply in natural, friendly conversational English.
  - If the user mixes Urdu and English, mirror that natural bilingual warmth.
- Never use markdown formatting, asterisks, bullet points, or emojis in the "reply" field since it goes straight to Text-to-Speech.

Android System Action Capabilities:
You can also control the user's Android phone when they ask. Always output valid JSON matching this exact schema:
{
  "reply": "Short natural spoken response for TTS",
  "language": "ur" or "en",
  "action": {
    "type": "NONE" | "OPEN_APP" | "SCROLL_DOWN" | "SCROLL_UP" | "CLICK_TEXT" | "GO_BACK" | "GO_HOME" | "READ_NOTIFICATIONS",
    "target": "app name or clickable UI text when applicable, otherwise empty string"
  }
}

Action guidelines:
- OPEN_APP: When user wants to open an app (e.g. "YouTube kholo", "Open WhatsApp", "Camera chalao"). Set target to the app name (e.g. "YouTube", "WhatsApp", "Camera").
- SCROLL_DOWN / SCROLL_UP: When user asks to scroll down/neeche or up/oopar.
- CLICK_TEXT: When user says click/tap/press on something visible (e.g. "Search par click karo", "Tap Send"). Set target to the visible label.
- GO_BACK / GO_HOME: When user wants to go back or return to the home screen.
- READ_NOTIFICATIONS: When user asks to read recent notifications or incoming messages aloud.
- NONE: For normal conversation, questions, jokes, advice, or general help.
"""
    }

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val conversationTurns = mutableListOf<Pair<String, String>>()

    suspend fun askTony(
        userMessage: String,
        recentNotifications: List<CapturedNotification>
    ): Result<TonyReply> = withContext(Dispatchers.IO) {
        try {
            val contentsArray = JSONArray()

            // Include recent conversation history (up to last 10 turns)
            conversationTurns.takeLast(10).forEach { (role, text) ->
                contentsArray.put(
                    JSONObject().apply {
                        put("role", role)
                        put("parts", JSONArray().put(JSONObject().put("text", text)))
                    }
                )
            }

            // Provide light context of recent notifications if user might be asking about them
            val notificationContext = if (recentNotifications.isNotEmpty()) {
                val summary = recentNotifications.take(5).joinToString(" | ") {
                    "${it.appName}: ${it.title} - ${it.body}"
                }
                "\n[Recent phone notifications available if user asks: $summary]"
            } else {
                ""
            }

            val currentUserPrompt = userMessage.trim() + notificationContext
            contentsArray.put(
                JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", currentUserPrompt)))
                }
            )

            val payload = JSONObject().apply {
                put(
                    "systemInstruction",
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT.trim()))
                    )
                )
                put("contents", contentsArray)
                put(
                    "generationConfig",
                    JSONObject().apply {
                        put("responseMimeType", "application/json")
                        put("temperature", 0.7)
                    }
                )
            }

            val request = Request.Builder()
                .url(ENDPOINT)
                .addHeader("Content-Type", "application/json")
                .addHeader("x-goog-api-key", GEMINI_API_KEY)
                .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()

            httpClient.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(
                        IllegalStateException("Gemini API error ${response.code}: $rawBody")
                    )
                }

                val root = JSONObject(rawBody)
                val text = root.optJSONArray("candidates")
                    ?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                    ?.optString("text")
                    ?.trim()
                    .orEmpty()

                if (text.isEmpty()) {
                    return@withContext Result.failure(IllegalStateException("Empty Gemini response"))
                }

                val parsed = parseTonyReply(text)

                // Save clean turn into conversation memory
                conversationTurns.add("user" to userMessage.trim())
                conversationTurns.add("model" to parsed.reply)
                if (conversationTurns.size > 20) {
                    repeat(2) { conversationTurns.removeAt(0) }
                }

                Result.success(parsed)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun clearMemory() {
        conversationTurns.clear()
    }

    private fun parseTonyReply(rawText: String): TonyReply {
        return try {
            val cleanJson = rawText
                .removePrefix("```json")
                .removePrefix("```")
                .removeSuffix("```")
                .trim()

            val obj = JSONObject(cleanJson)
            val reply = obj.optString("reply").ifBlank { "Jee, main sun raha hoon." }
            val language = obj.optString("language", "ur").lowercase()
            val actionObj = obj.optJSONObject("action")
            val typeStr = actionObj?.optString("type", "NONE")?.uppercase() ?: "NONE"
            val target = actionObj?.optString("target", "").orEmpty()

            val actionType = runCatching { TonyActionType.valueOf(typeStr) }
                .getOrDefault(TonyActionType.NONE)

            TonyReply(
                reply = reply,
                language = if (language == "en") "en" else "ur",
                action = TonyAction(type = actionType, target = target)
            )
        } catch (_: Exception) {
            TonyReply(
                reply = rawText.replace("*", "").trim(),
                language = "ur",
                action = TonyAction()
            )
        }
    }
}
